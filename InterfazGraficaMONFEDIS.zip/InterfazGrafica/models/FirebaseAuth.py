from pydantic import BaseModel
from typing import Optional

class FirebaseAuth(BaseModel):
    #{
    #"localId": "ZY1rJK0eYLg...",
    #"email": "[user@example.com]",
    #"displayName": "",
    #"idToken": "[ID_TOKEN]",
    #"registered": true,
    #"refreshToken": "[REFRESH_TOKEN]",
    #"expiresIn": "3600"
    #}
    kind: Optional[str] = None
    localId: str
    email: str
    displayName: Optional[str] = None
    idToken: str
    registered: Optional[bool] = None
    refreshToken: str
    expiresIn: str
    