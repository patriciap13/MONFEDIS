import json
import random
import re
import uuid
from faker import Faker
import flet as ft
from pydantic import InstanceOf
import requests

from models.FirebaseAuth import FirebaseAuth
from models.FirebaseConnect import FirebaseConnect


class RegisterSportmanPage:
    _page: ft.Page
    route: str
    view_pop: callable(any)

    firebaseConnect: FirebaseConnect
    firebaseAuth: FirebaseAuth

    _alert_dialog: ft.Container

    _loading_dialog: ft.AlertDialog
    _error_dialog: ft.Control

    _view: ft.View

    def showLoading(self):
        """
        Show a loading dialog.
        """

        self._loading_dialog = ft.Container(
            width=100,
            height=100,
            alignment=ft.Alignment(0, 0),
            content=ft.ProgressRing(
                width=100,
                height=100,
                expand=True,
                stroke_width=5,
            ),
            expand=False,
        )
        self._alert_dialog.visible = True
        self._alert_dialog.content = self._loading_dialog
        self._alert_dialog.update()

    def hideLoading(self):
        """
        Hide the loading dialog.
        """
        self._alert_dialog.visible = False
        self._alert_dialog.update()
        self._alert_dialog.content = None
        print("hideLoading end")

    def showErrorMessage(self, message: str):
        print("showErrorMessage")
        self._error_dialog = ft.Container(
            width=400,
            height=400,
            alignment=ft.Alignment(0, 0),
            bgcolor=ft.colors.BACKGROUND,
            border_radius=10,
            content=ft.Column(
                expand=False,
                controls=[
                    ft.Icon(
                        name=ft.icons.ERROR,
                        size=100,
                        color="#D43131C5",
                    ),
                    ft.Text(
                        message,
                        size=32,
                        text_align=ft.TextAlign.CENTER,
                        weight=ft.FontWeight.W_400,
                    ),
                    ft.ElevatedButton(
                        text="CLOSE",
                        on_click=lambda e: self.hideErrorMessage(),
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_EVENLY,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )
        self._alert_dialog.visible = True
        self._alert_dialog.content = self._error_dialog
        self._alert_dialog.update()

    def hideErrorMessage(self):
        self._alert_dialog.visible = False
        self._alert_dialog.update()
        self._alert_dialog.content = None

    def __new__(
        cls,
        page: ft.Page,
        route: str,
        firebaseAuthString: str,
        view_pop: callable(any),
    ) -> ft.View:
        print("SheetPage new")
        self = super().__new__(cls)
        self.route = route
        self._page = page
        self.view_pop = view_pop

        self.firebaseAuth = FirebaseAuth.model_validate_json(firebaseAuthString)
        self._alert_dialog = ft.Container(
            visible=False,
            expand=True,
            alignment=ft.Alignment(0, 0),
            bgcolor=ft.colors.BLACK38,
        )

        self.firebaseConnect = FirebaseConnect()

        ## contenido

        ## titulo
        page_title = ft.Container(
            content=ft.Text(
                "Agregar Deportista",
                size=32,
                text_align="center",
                font_family="century gothic",
                color="#1D5B79",
                weight=ft.FontWeight.W_400,
            ),
            alignment=ft.alignment.center,
            width=600,
            border_radius=100,
            padding=ft.padding.symmetric(horizontal=10),
            bgcolor="#0F5663C6",
        )

        def button_clicked(e):
            # t.value = f"Datos Registro Entrenador: '{nombre_sportman.value}', '{apellido_sportman.value}', '{email_sportman.value}', '{password_sportman.value}', '{conf_password_sportman.value}'. "
            # t.update()
            self.showLoading()
            name = nombre_sportman.value
            lastname = apellido_sportman.value
            document = documento_sportman.value
            gender = genero_sportman.value
            age = edad_sportman.value
            weight = peso_sportman.value
            height = estatura_sportman.value

            if name is None or name == "":
                self.showErrorMessage(f"El nombre es requerido")
                return
            if lastname is None or lastname == "":
                self.showErrorMessage(f"El apellido es requerido")
                return
            if document is None or document == "":
                self.showErrorMessage(f"El documento es requerido")
                return
            if gender is None or gender == "":
                self.showErrorMessage(f"El genero es requerido")
                return
            if age is None or age == "":
                self.showErrorMessage(f"La edad es requerida")
                return
            if weight is None or weight == "":
                self.showErrorMessage(f"El peso es requerido")
                return
            if height is None or height == "":
                self.showErrorMessage(f"La estatura es requerida")
                return
            
            unique_id = uuid.uuid4().__str__()

            try:
                loadData = self.firebaseConnect.putData(
                    path=f"us_{self.firebaseAuth.localId}/sportsmen/{unique_id}/",
                    data={
                        "userInformation": {
                            "name": name,
                            "lastname": lastname,
                            "document": document,
                            "gender": gender,
                            "age": age,
                            "weight": weight,
                            "height": height,
                        }
                    },
                    token=self.firebaseAuth.idToken,
                )
                
                if loadData:
                        self.showErrorMessage(f"Registro Exitoso")
                        self.view_pop(None)
                        #self.hideLoading()
                else:
                    self.showErrorMessage(f"Registro Fallido")
            except Exception as e:
                print(e)
                self.showErrorMessage(f"Registro Fallido")

        t = ft.Text()
        nombre_sportman = ft.TextField(label="Nombre")
        apellido_sportman = ft.TextField(label="Apellido")
        documento_sportman = ft.TextField(label="Documento")
        genero_sportman = ft.TextField(label="Genero")
        edad_sportman = ft.TextField(label="Edad")
        peso_sportman = ft.TextField(label="Peso")
        estatura_sportman = ft.TextField(label="Estatura")

        Botones = ft.Container(
            content=ft.Row(
                [
                    ft.ElevatedButton(
                        text="Registrar Deportista", on_click=button_clicked
                    ),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
            )
        )

        self._view = ft.View(
            route=self.route,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            vertical_alignment=ft.MainAxisAlignment.CENTER,
            fullscreen_dialog=True,
            controls=[
                ft.Stack(
                    width=self._page.window_width,
                    height=self._page.window_height,
                    controls=[
                        ft.IconButton(
                            icon=ft.icons.ARROW_BACK,
                            icon_size=30,
                            tooltip="Back",
                            on_click=lambda e: self.view_pop(None),
                        ),
                        ft.Column(
                            alignment=ft.MainAxisAlignment.START,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=[
                                page_title,
                                ft.Container(
                                    expand=True,
                                    alignment=ft.Alignment(0, 0),
                                    content=ft.Column(
                                        scroll=ft.ScrollMode.AUTO,
                                        controls=[
                                            ft.Row(
                                                [nombre_sportman],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [apellido_sportman],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [documento_sportman],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [genero_sportman],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [edad_sportman],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [peso_sportman],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [estatura_sportman],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [Botones],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                        ],
                                    ),
                                ),
                            ],
                        ),
                        self._alert_dialog,
                    ],
                ),
            ],
        )
        return self._view
