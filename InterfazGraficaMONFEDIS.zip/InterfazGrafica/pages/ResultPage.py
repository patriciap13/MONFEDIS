import json
import math
import random
import re
from faker import Faker
import flet as ft
from pydantic import InstanceOf
import requests

from models.FirebaseAuth import FirebaseAuth
from models.FirebaseConnect import FirebaseConnect


class ResultPage:
    _page: ft.Page
    route: str
    view_pop: callable(any)

    firebaseConnect: FirebaseConnect

    firebaseAuth: FirebaseAuth

    _alert_dialog: ft.Container

    _loading_dialog: ft.AlertDialog
    _error_dialog: ft.Control

    _view: ft.View

    def showLoading(self):
        """
        Show a loading dialog.
        """

        self._loading_dialog = ft.Container(
            width=100,
            height=100,
            alignment=ft.Alignment(0, 0),
            content=ft.ProgressRing(
                width=100,
                height=100,
                expand=True,
                stroke_width=5,
            ),
            expand=False,
        )
        self._alert_dialog.visible = True
        self._alert_dialog.content = self._loading_dialog
        self._alert_dialog.update()

    def hideLoading(self):
        """
        Hide the loading dialog.
        """
        self._alert_dialog.visible = False
        self._alert_dialog.update()
        self._alert_dialog.content = None
        print("hideLoading end")

    def showErrorMessage(self, message: str):
        print("showErrorMessage")
        self._error_dialog = ft.Container(
            width=400,
            height=400,
            alignment=ft.Alignment(0, 0),
            bgcolor=ft.colors.BACKGROUND,
            border_radius=10,
            content=ft.Column(
                expand=False,
                controls=[
                    ft.Icon(
                        name=ft.icons.ERROR,
                        size=100,
                        color="#D43131C5",
                    ),
                    ft.Text(
                        message,
                        size=32,
                        text_align=ft.TextAlign.CENTER,
                        weight=ft.FontWeight.W_400,
                    ),
                    ft.ElevatedButton(
                        text="CLOSE",
                        on_click=lambda e: self.hideErrorMessage(),
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_EVENLY,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )
        self._alert_dialog.visible = True
        self._alert_dialog.content = self._error_dialog
        self._alert_dialog.update()

    def hideErrorMessage(self):
        self._alert_dialog.visible = False
        self._alert_dialog.update()
        self._alert_dialog.content = None

    def __new__(
        cls,
        page: ft.Page,
        route: str,
        firebaseAuthString: str,
        sportmanResultString: str,
        view_pop: callable(any),
    ) -> ft.View:
        print("ResultPage __new__")
        self = super().__new__(cls)
        self.route = route
        self._page = page
        self.view_pop = view_pop

        self.firebaseAuth = FirebaseAuth.model_validate_json(firebaseAuthString)
        sportmanResult = json.loads(sportmanResultString)

        self._alert_dialog = ft.Container(
            visible=False,
            expand=True,
            alignment=ft.Alignment(0, 0),
            bgcolor=ft.colors.BLACK38,
        )

        self.firebaseConnect = FirebaseConnect()

        dataToWork = []

        for key in sportmanResult:
            for key2 in sportmanResult[key]:
                val1 = sportmanResult.get(key)
                if isinstance(key2, str):
                    dataToWork.append(val1.get(key2))
                    continue
                dataToWork.append(key2)

        ## contenido

        ## titulo
        page_title = ft.Container(
            content=ft.Text(
                value="Datos del Deportista",
                size=32,
                text_align="center",
                font_family="century gothic",
                color="#1D5B79",
                weight=ft.FontWeight.W_400,
            ),
            alignment=ft.alignment.center,
            width=600,
            border_radius=100,
            padding=ft.padding.symmetric(horizontal=10),
            bgcolor="#0F5663C6",
        )

        deportista_data = []

        def open_sporty(e):
            print("open_sporty")
            print(e.control.data)
            data = json.dumps(e.control.data)
            # self._page.go(
            #    "/sportman",
            #    firebaseAuth=self.firebaseAuth.model_dump_json(),
            #    sportman=data,
            # )

        bpm_list = []
        lat_list = []
        lon_list = []

        for key in dataToWork:
            try:
                print(key)
                if key == None:
                    continue
                print(key)
                if not isinstance(key, str):
                    value = key
                    bpm_list.append(float(value["bpm"]))
                    lat_list.append(float(value["lat"]))
                    lon_list.append(float(value["lon"]))

                else:
                    value = dataToWork[key]
                    bpm_list.append(value["bpm"])
                    lat_list.append(value["lat"])
                    lon_list.append(value["lon"])

            except Exception as e:
                print(e)
                print("Error al obtener datos del usuario")

        bpm_prom = sum(bpm_list) / len(bpm_list)

        def haversine(lat1, lon1, lat2, lon2):
            # Convertir las coordenadas de grados a radianes
            lat1 = math.radians(lat1)
            lon1 = math.radians(lon1)
            lat2 = math.radians(lat2)
            lon2 = math.radians(lon2)

            # Diferencias de latitud y longitud
            dlat = lat2 - lat1
            dlon = lon2 - lon1

            # Aplicar la fórmula haversine
            a = (
                math.sin(dlat / 2) ** 2
                + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
            )
            c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
            R = 6371  # Radio de la Tierra en kilómetros
            distance = R * c

            return distance

        distancia = 0
        distancia_list = []
        for i in range(len(lat_list)):
            if i == 0:
                distancia_list.append(0)
                continue
            distancia = haversine(
                lat_list[i - 1], lon_list[i - 1], lat_list[i], lon_list[i]
            )
            distancia_list.append(distancia)

        print(
            f"{len(bpm_list)} - {len(lat_list)} - {len(lon_list)} - {len(distancia_list)}"
        )

        for i in range(len(bpm_list)):
            deportista_data.append(
                ft.ListTile(
                    width=400,
                    title=ft.Text(
                        value=f"bpm: {bpm_list[i].__round__(2)} - lat: {lat_list[i]} - lon: {lon_list[i]} - distancia: {distancia_list[i].__round__(2) if i>0 else 0} km",
                    ),
                    # on_click=open_sporty,
                )
            )

        line_chart_data = []

        append_distancia = 0
        for i in range(len(bpm_list)):
            append_distancia += distancia_list[i] * 1000
            line_chart_data.append(
                ft.LineChartDataPoint(
                    x=append_distancia,
                    y=bpm_list[i],
                )
            )

        data_1 = [
            ft.LineChartData(
                data_points=line_chart_data,
                stroke_width=2,
                color=ft.colors.CYAN,
                curved=False,
                stroke_cap_round=True,
            )
        ]

        self._view = ft.View(
            route=self.route,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            vertical_alignment=ft.MainAxisAlignment.CENTER,
            fullscreen_dialog=True,
            controls=[
                ft.Stack(
                    width=self._page.window_width,
                    height=self._page.window_height,
                    controls=[
                        ft.Column(
                            alignment=ft.MainAxisAlignment.START,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            scroll=ft.ScrollMode.AUTO,
                            controls=[
                                page_title,
                                ft.Divider(
                                    color=ft.colors.TRANSPARENT,
                                ),
                                ft.Row(
                                    [
                                        ft.Container(
                                            content=ft.Text(
                                                value=f"bpm promedio: \n{bpm_prom.__round__(2)}",
                                                size=32,
                                                text_align="center",
                                                font_family="century gothic",
                                                color="#1D5B79",
                                                weight=ft.FontWeight.W_400,
                                            ),
                                        ),
                                        ft.Container(
                                            content=ft.Text(
                                                value=f"distancia recorrida: \n{sum(distancia_list).__round__(2)} km",
                                                size=32,
                                                text_align="center",
                                                font_family="century gothic",
                                                color="#1D5B79",
                                                weight=ft.FontWeight.W_400,
                                            ),
                                        ),
                                    ],
                                    alignment=ft.MainAxisAlignment.CENTER,
                                    vertical_alignment=ft.CrossAxisAlignment.START,
                                    wrap=True,
                                ),
                                ft.Container(
                                    content=ft.LineChart(
                                        data_series=data_1,
                                        expand=True,
                                        horizontal_grid_lines=ft.ChartGridLines(
                                            
                                        ),
                                        vertical_grid_lines=ft.ChartGridLines(
                                            
                                        ),
                                        
                                        left_axis=ft.ChartAxis(
                                            title=ft.Text(
                                                value="bpm",
                                                size=32,
                                                text_align="center",
                                                font_family="century gothic",
                                                color="#1D5B79",
                                                weight=ft.FontWeight.W_400,
                                            ),
                                            title_size=50,
                                            labels_size=50,
                                        ),
                                        baseline_x=0,
                                        bottom_axis=ft.ChartAxis(
                                            title=ft.Text(
                                                value="distancia (m)",
                                                size=32,
                                                text_align="center",
                                                font_family="century gothic",
                                                color="#1D5B79",
                                                weight=ft.FontWeight.W_400,
                                            ),
                                            title_size=50,
                                            labels_size=50,
                                        ),
                                    ),
                                    bgcolor=ft.colors.WHITE,
                                    width=600,
                                    height=600,
                                    margin=ft.margin.all(10),
                                ),
                                ft.Container(
                                    alignment=ft.Alignment(0, 0),
                                    content=ft.Column(
                                        alignment=ft.MainAxisAlignment.START,
                                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                        controls=deportista_data,
                                    ),
                                ),
                                ft.Divider(
                                    color=ft.colors.TRANSPARENT,
                                ),
                            ],
                        ),
                        ft.IconButton(
                            icon=ft.icons.ARROW_BACK,
                            icon_size=30,
                            tooltip="Back",
                            on_click=lambda e: self.view_pop(None),
                        ),
                        self._alert_dialog,
                    ],
                ),
            ],
        )
        return self._view
