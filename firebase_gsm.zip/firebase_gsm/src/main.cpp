#include <Arduino.h>
#include <Wire.h>
#include "esp_adc_cal.h"

// SIM7000G GPRS settings

#define TINY_GSM_MODEM_SIM7000SSL // Modem is SIM7000G with SSL support
#define TINY_GSM_RX_BUFFER 1024   // Set RX buffer to 1Kb

// define the Serial por to the SIM7000G
#define SerialAT Serial1
// Set serial for debug console (to the Serial Monitor, default speed 115200)
#define SerialMon Serial

// set the flags to use ssl and gprs
#define TINY_GSM_USE_GPRS true
#define TINY_GSM_SSL_CLIENT_AUTHENTICATION

#include <TinyGsmClient.h>
#include <SPI.h>
#include <SD.h>
// #include <Ticker.h>
#include <ArduinoHttpClient.h>

// Define the port used for the connection using TinyGsmClient
TinyGsm modem(SerialAT);
TinyGsmClientSecure client;

// Your GPRS credentials, if any
// const char apn[] = "web.colombiamovil.com.co"; //"internet.movistar.com.co"; // SET TO YOUR APN
const char apn[] = "internet.movistar.com.co"; // SET TO YOUR APN
const char gprsUser[] = "";
const char gprsPass[] = "";

// LilyGO T-SIM7000G Pinout
#define UART_BAUD 115200
#define PIN_DTR 25
#define PIN_TX 27
#define PIN_RX 26
#define PWR_PIN 4
#define LED_PIN 12
#define BUTTON_PIN 25

#define LED_RED 14
#define LED_GREEN 15
#define LED_BLUE 2

// ----------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------
// Ad8232 settings

#define ADC_INPUT ADC1_CHANNEL_7 // pin 35 output of ad8232

unsigned long pqr_time = 0;
unsigned long lastTimePQR = 0;
int pqr_count = 0;
double HR = 0;
double timeHR = 0;

String gps_raw = "";
float lat = 0;
String latToSend = "0.0";
float lon = 0;
String lonToSend = "0.0";

// Define variables para el filtro digital pqr
int x1 = 0;
int x2 = 0;
int x = 0;
int y = 0;
int y_1 = 0;
int y_2 = 0;
int threshold = 41;              // Set the threshold value // umbral para determinar si es un pico
int peaks = 0;                   // Create a variable to store the peak
bool waitingForNextPeak = false; // Variable para rastrear si estamos esperando el próximo pico
int waitCycles = 36;             // Número de ciclos (8 ms cada uno) que se deben esperar antes de permitir la próxima actualización de peaks
int currentWaitCycles = 0;       // Contador de ciclos actuales

unsigned long lastTime = 0;

int pinShutdownAd8232 = 0; // pin to shutdown the ad8232 ~SDN
#define sleepPin 25
#define gpioSleepPin GPIO_NUM_25

hw_timer_t *timer = NULL;

bool syncDevice = false;
bool buttonPressed = false;

int buttonState = 0;

// ----------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------

// Firebase Settings

// Insert Firebase project API Key
#define API_KEY "AIzaSyDKqRz-5vTzEOlaYGd66YEQA72YeISa6Vc"

// Insert RTDB URLefine the RTDB URL */
#define FIREBASE_RTDB_HOST "monitorcardiacogps-default-rtdb.firebaseio.com"
const String FIREBASE_AUTH = "yXJow02qoOhgFwUqtfojDWBsjmBXuZ2Iirp86dn6";
#define SSL_PORT 443

HttpClient httpFirebaseRTDB(client, FIREBASE_RTDB_HOST, SSL_PORT);

// data to send to the RTDB
unsigned long sendDataPrevMillis = 0;
unsigned long takeDataPrevMillis = 0;
int count = 0;
int countToSend = 0;
#define FIREBASE_MAX_SEND_DATA 5

// StaticJsonDocument<1024> doc;
String dev_id = "dev_0";
String dataToSend[] = {"", ""};
int countBuffer = 0;
int bufferToSend = 0;
String path = "";
int status = 0;

// ----------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------
// ----------------------------------------------------------------------------------------

void PostToFirebase(const String &path, const String &data, HttpClient *http);
String GetToFirebase(const String &path, HttpClient *http);
void appendDataToSend(String bpm, String lat, String lon);
String getFromJson(String data, String key);

void IRAM_ATTR onTimer()
{

  x2 = x1;
  x1 = x;
  x = adc1_get_raw(ADC_INPUT);
  y_2 = y_1;
  y_1 = y;
  y = double(0.09634836 * x);
  y -= double(0.09634836 * x2);
  y += double(1.25956033 * y_1);
  y -= double(0.80730328 * y_2);

  // Check if we're waiting for the next peak
  if (waitingForNextPeak)
  {
    if (currentWaitCycles >= waitCycles)
    {
      waitingForNextPeak = false;
      peaks = 0;
      currentWaitCycles = 0;
      if ((y < -threshold || y > threshold))
      {
        peaks = 4095;
        // peak_time = millis();
        waitingForNextPeak = true;
      }
    }
    else
    {
      currentWaitCycles++;
    }
  }
  else
  {
    // Store the y value in the peaks variable when it's 4095
    if ((y < -threshold || y > threshold))
    {
      peaks = 4095;
      // peak_time = millis();
      waitingForNextPeak = true;
      pqr_count++;
      pqr_time += millis() - lastTimePQR;
      lastTimePQR = millis();
    }
  }

  if (millis() - takeDataPrevMillis > 10000 && status == 1 && syncDevice == true)
  {
    takeDataPrevMillis = millis();
    // Serial.print("pqr_time: ");
    // Serial.print(pqr_time);
    // Serial.print("\t");
    // Serial.print("pqr_count: ");
    // Serial.print(pqr_count);
    // Serial.print("\t");
    // Serial.print("HR: ");
    // Serial.print(HR, 3); // Imprime HR con 2 decimales
    // Serial.print("\t");
    timeHR = double(pqr_time) / 1000.0;
    // Serial.print("timeHR: ");
    // Serial.print(timeHR, 3); // Imprime timesss con 2 decimales
    // Serial.print("\t");
    HR = timeHR / (pqr_count - 1);
    // Serial.print("HR: ");
    // Serial.print(HR, 3); // Imprime HR con 2 decimales
    // Serial.println();    // Agrega un salto de línea al final
    HR = 60 / HR;
    // HR = double(60000 / double(pqr_time / pqr_count));

    pqr_time = 0;
    pqr_count = 0;

    // Serial.printf("HR: ");
    // Serial.println(HR);

    // appendDataToSend(String(HR), String(latToSend), String(lonToSend));

    appendDataToSend(String(HR), latToSend, lonToSend);
    HR = 0;

    /* doc[count][0]="000000"+String(count);
    doc[count][1]="-73.1188716990988"+String(count);
    doc[count][2]="-73.1188716990987"+String(count);
    doc[count][3]=String(200, HEX);
    doc[count][4]="0000000"; */

    count++;
    countToSend++;
  }
}

String splitter(String data, char separator, int index)
{
  int stringData = 0;
  String dataPart = "";

  for (int i = 0; i < data.length(); i++)
  {

    if (data[i] == separator)
    {

      stringData++;
    }
    else if (stringData == index)
    {

      dataPart.concat(data[i]);
    }
    else if (stringData > index)
    {

      return dataPart;
      break;
    }
  }

  return dataPart;
}

void enableGPS(void)
{
  // Set SIM7000G GPIO4 LOW ,turn on GPS power
  // CMD:AT+SGPIO=0,4,1,1
  // Only in version 20200415 is there a function to control GPS power
  modem.sendAT("+CGPIO=0,48,1,1");
  if (modem.waitResponse(10000L) != 1)
  {
    DBG("Set GPS Power HIGH Failed");
  }
  modem.enableGPS();
}

void disableGPS(void)
{
  // Set SIM7000G GPIO4 LOW ,turn off GPS power
  // CMD:AT+SGPIO=0,4,1,0
  // Only in version 20200415 is there a function to control GPS power
  modem.sendAT("+CGPIO=0,48,1,0");
  if (modem.waitResponse(10000L) != 1)
  {
    DBG("Set GPS Power LOW Failed");
  }
  modem.disableGPS();
}

// function to power on the SIM7000G
void modemPowerOn()
{
  pinMode(PWR_PIN, OUTPUT);
  digitalWrite(PWR_PIN, LOW);
  delay(1000);
  digitalWrite(PWR_PIN, HIGH);
}

// function to power off the SIM7000G
void modemPowerOff()
{
  pinMode(PWR_PIN, OUTPUT);
  digitalWrite(PWR_PIN, LOW);
  delay(1500);
  digitalWrite(PWR_PIN, HIGH);
}

// function to restart the SIM7000G
void modemRestart()
{
  modemPowerOff();
  delay(1000);
  modemPowerOn();
}

void initModem()
{
  // Set GSM module baud rate
  SerialAT.begin(115200, SERIAL_8N1, PIN_RX, PIN_TX);
  delay(3000);

  // Restart takes quite some time
  // To skip it, call init() instead of restart()
  SerialMon.println("Initializing modem...");
  modem.restart();

  bool res = modem.setNetworkMode(2);
  if (!res)
  {
    ("setNetworkMode  false ");
  }

  String modemInfo = modem.getModemInfo();
  SerialMon.print("Modem Info: ");
  SerialMon.println(modemInfo);

  // Or, use Adafruit's Helper function to unlock your SIM with a PIN
  // Adafruit_FONA_LTE_UnlockSIM(FONA_PW);

  SerialMon.print("Waiting for network...");
  if (!modem.waitForNetwork())
  {
    SerialMon.println(" fail");
    delay(10000);
    return;
  }
  SerialMon.println(" success");

  if (modem.isNetworkConnected())
  {
    SerialMon.println("Network connected");
  }

  SerialMon.print(F("Connecting to "));
  SerialMon.print(apn);
  if (!modem.gprsConnect(apn, gprsUser, gprsPass))
  {
    SerialMon.println(" fail");
    delay(10000);
    return;
  }
  SerialMon.println(" success");

  if (modem.isGprsConnected())
  {
    SerialMon.println("GPRS connected");
  }

  enableGPS();
}

void setup()
{

  setCpuFrequencyMhz(80);
  SerialMon.begin(115200);
  SerialMon.println("Starting...");

  pinMode(pinShutdownAd8232, OUTPUT);
  digitalWrite(pinShutdownAd8232, LOW);

  pinMode(LED_RED, OUTPUT);
  pinMode(LED_GREEN, OUTPUT);
  pinMode(LED_BLUE, OUTPUT);
  digitalWrite(LED_RED, HIGH);
  digitalWrite(LED_GREEN, LOW);
  digitalWrite(LED_BLUE, LOW);

  SerialMon.println("ad8232 off");
  // pinMode(sleepPin, OUTPUT);
  pinMode(BUTTON_PIN, INPUT_PULLUP);
  esp_sleep_enable_ext0_wakeup(gpioSleepPin, 0);
  SerialMon.println("esp_sleep_enable_ext0_wakeup");

  // setting adc to read from pin ADC_INPUT with 12 bits of resolution
  adc1_config_width(ADC_WIDTH_BIT_12);
  adc1_config_channel_atten(ADC_INPUT, ADC_ATTEN_DB_11);

  // create a interrupt each 4ms
  timer = timerBegin(0, 80, true);
  timerAttachInterrupt(timer, &onTimer, true);
  timerAlarmWrite(timer, 8000, true);

  // set LED off
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  // power on the SIM7000G
  modemPowerOn();
  SerialMon.println("SIM7000G powered on");

  delay(1000);

  // initialize the modem
  initModem();

  delay(10000);

  client.init(&modem, 0);
  httpFirebaseRTDB.connectionKeepAlive();
  httpFirebaseRTDB.setHttpResponseTimeout(5000);
  digitalWrite(LED_RED, LOW);
  digitalWrite(LED_GREEN, LOW);
  digitalWrite(LED_BLUE, LOW);
}

void loop()
{
  // gps_raw = modem.getGPSraw();
  // if (gps_raw != "")
  //{
  //   lat = splitter(gps_raw, ',', 3); // ±dd.dddddd
  //   lon = splitter(gps_raw, ',', 4); // ±ddd.dddddd
  //   SerialMon.printf("lat: %s lon: %s\n", lat.c_str(), lon.c_str());
  // }
  if (modem.getGPS(&lat, &lon))
  {
    latToSend = String(lat, 9);
    lonToSend = String(lon, 9);
  }
  while (digitalRead(BUTTON_PIN) == LOW)
  {
    if (!buttonPressed)
    {
      lastTime = millis();
      buttonPressed = true;
    }

    unsigned long currentTime = millis();
    unsigned long elapsedTime = currentTime - lastTime;

    if (elapsedTime >= 5000 && elapsedTime <= 7000)
    {
      Serial.println("Time to sync");
      buttonState = 1; // 1 is for sync
      digitalWrite(LED_GREEN, HIGH);
      digitalWrite(LED_BLUE, LOW);
      digitalWrite(LED_RED, LOW);
    }
    else if (elapsedTime >= 10000 && elapsedTime <= 12000)
    {
      Serial.println("Time to shutdown");
      buttonState = 2; // 2 is for shutdown
      digitalWrite(LED_GREEN, LOW);
      digitalWrite(LED_BLUE, HIGH);
      digitalWrite(LED_RED, LOW);
    }
    else
    {
      buttonState = 0;
      digitalWrite(LED_GREEN, LOW);
      digitalWrite(LED_BLUE, LOW);
      digitalWrite(LED_RED, LOW);
    }
  }
  if (buttonPressed == true)
  {
    digitalWrite(LED_GREEN, LOW);
    digitalWrite(LED_BLUE, LOW);
    digitalWrite(LED_RED, LOW);
    SerialMon.printf("buttonState: %d\n", buttonState);
    if (buttonState == 1)
    {

      buttonPressed = false;
      buttonState = 0;
      syncDevice = true;
      if (syncDevice)
      {
        timerAlarmEnable(timer);
        // set the shutdown pin of the ad8232 to high
        SerialMon.println("ad8232 on");
        digitalWrite(pinShutdownAd8232, HIGH);
      }
    }
    else if (buttonState == 2)
    {
      buttonPressed = false;
      buttonState = 0;
      status = 0;
      syncDevice = false;
      timerAlarmDisable(timer);
      // set the shutdown pin of the ad8232 to low
      SerialMon.println("ad8232 off");
      digitalWrite(pinShutdownAd8232, LOW);
      modemPowerOff();
    }
    else
    {
      buttonPressed = false;
      buttonState = 0;
    }
  }

  if (countToSend == FIREBASE_MAX_SEND_DATA && status == 1 && syncDevice == true)
  {
    /* String data;
    serializeJson(doc, data);
    PostToFirebase("PUT", "/test", data, &httpFirebaseRTDB);
    doc.clear(); */

    if (countBuffer == 0)
    {
      countBuffer = 1;
      bufferToSend = 0;
      countToSend = 0;
    }
    else
    {
      countBuffer = 0;
      bufferToSend = 1;
      countToSend = 0;
    }
    digitalWrite(LED_GREEN, LOW);
    digitalWrite(LED_BLUE, LOW);
    digitalWrite(LED_RED, HIGH);
    PostToFirebase("/" + path, dataToSend[bufferToSend], &httpFirebaseRTDB);
    digitalWrite(LED_GREEN, LOW);
    digitalWrite(LED_BLUE, LOW);
    digitalWrite(LED_RED, LOW);
    dataToSend[bufferToSend] = "";
    sendDataPrevMillis = millis();
  }
  else if (status == 0 && syncDevice == true)
  {
    digitalWrite(LED_GREEN, LOW);
    digitalWrite(LED_BLUE, LOW);
    digitalWrite(LED_RED, HIGH);
    String response = GetToFirebase("/" + dev_id, &httpFirebaseRTDB);
    if (response != "")
    {
      path = getFromJson(response, "path");
      status = getFromJson(response, "status").toInt();
    }
    digitalWrite(LED_GREEN, LOW);
    digitalWrite(LED_BLUE, LOW);
    digitalWrite(LED_RED, LOW);
    if (response != "")
    {
      delay(500);
      digitalWrite(LED_GREEN, HIGH);
      digitalWrite(LED_BLUE, LOW);
      digitalWrite(LED_RED, LOW);
      delay(500);
      digitalWrite(LED_GREEN, LOW);
      digitalWrite(LED_BLUE, LOW);
      digitalWrite(LED_RED, LOW);
      delay(500);
      digitalWrite(LED_GREEN, HIGH);
      digitalWrite(LED_BLUE, LOW);
      digitalWrite(LED_RED, LOW);
      delay(500);
      digitalWrite(LED_GREEN, LOW);
      digitalWrite(LED_BLUE, LOW);
      digitalWrite(LED_RED, LOW);
    }
  }

  /*
  SerialMon.println("loop");
  SerialMon.println(millis());
  String contentType = "application/json";
  String data = "{\"test_" + String(count) + "\":\"test\"}";
  httpFirebaseRTDB.post("/test.json?auth=" + FIREBASE_AUTH, contentType, data);
  SerialMon.printf("Status code: %d\n", httpFirebaseRTDB.responseStatusCode());
  SerialMon.printf("Response: %s\n", httpFirebaseRTDB.responseBody().c_str());
  SerialMon.println(millis());
  SerialMon.println("loop end");
  count++; */
}

String getFromJson(String data, String key)
{
  int index = data.indexOf(key);
  if (index == -1)
  {
    return "";
  }
  String value = "";
  for (int i = index + key.length() + 3; i < data.length(); i++)
  {
    if (data[i] == '"')
    {
      break;
    }
    value += data[i];
  }
  return value;
}

void appendDataToSend(String bpm, String lat, String lon)
{
  if (countToSend == 0)
  {
    dataToSend[countBuffer] += "{";
  }

  dataToSend[countBuffer] += "\"" + String(count) + "\":{\"bpm\":\"" + bpm + "\",";
  dataToSend[countBuffer] += "\"lat\":\"" + lat + "\",";
  dataToSend[countBuffer] += "\"lon\":\"" + lon + "\"}";
  if (countToSend < FIREBASE_MAX_SEND_DATA - 1)
  {
    dataToSend[countBuffer] += ",";
  }
  else
  {
    dataToSend[countBuffer] += "}";
  }
}

void PostToFirebase(const String &path, const String &data, HttpClient *http)
{
  String response;
  int statusCode = 0;
  http->connectionKeepAlive(); // Currently, this is needed for HTTPS

  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
  String url = "/" + path;
  url += ".json";
  url += "?auth=" + FIREBASE_AUTH;
  Serial.print("POST:");
  Serial.println(url);
  Serial.print("Data:");
  Serial.println(data);
  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN

  String contentType = "application/json";
  http->post(url, contentType, data);

  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
  //  read the status code and body of the response
  // statusCode-200 (OK) | statusCode -3 (TimeOut)
  statusCode = http->responseStatusCode();
  Serial.print("Status code: ");
  Serial.println(statusCode);
  response = http->responseBody();
  Serial.print("Response: ");
  Serial.println(response);
  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN

  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
  if (!http->connected())
  {
    Serial.println();
    http->stop(); // Shutdown
    Serial.println("HTTP POST disconnected");
  }
  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
}

String GetToFirebase(const String &path, HttpClient *http)
{
  String response;
  int statusCode = 0;
  http->connectionKeepAlive(); // Currently, this is needed for HTTPS

  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
  String url = "/" + path;
  url += ".json";
  url += "?auth=" + FIREBASE_AUTH;
  Serial.print("GET:");
  Serial.println(url);
  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN

  String contentType = "application/json";
  http->get(url);

  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
  //  read the status code and body of the response
  // statusCode-200 (OK) | statusCode -3 (TimeOut)
  statusCode = http->responseStatusCode();
  Serial.print("Status code: ");
  Serial.println(statusCode);
  response = http->responseBody();
  Serial.print("Response: ");
  Serial.println(response);
  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN

  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
  if (!http->connected())
  {
    Serial.println();
    http->stop(); // Shutdown
    Serial.println("HTTP POST disconnected");
  }

  return response;
  // NNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNN
}
