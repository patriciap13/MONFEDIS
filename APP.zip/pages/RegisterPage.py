import json
import random
import re
from faker import Faker
import flet as ft
from pydantic import InstanceOf
import requests

from models.FirebaseAuth import FirebaseAuth
from models.FirebaseConnect import FirebaseConnect



class RegisterPage:
    _page: ft.Page
    route: str
    view_pop: callable(any)

    firebaseConnect: FirebaseConnect

    _alert_dialog: ft.Container

    _loading_dialog: ft.AlertDialog
    _error_dialog: ft.Control

    _view: ft.View

    def showLoading(self):
        """
        Show a loading dialog.
        """

        self._loading_dialog = ft.Container(
            width=100,
            height=100,
            alignment=ft.Alignment(0, 0),
            content=ft.ProgressRing(
                width=100,
                height=100,
                expand=True,
                stroke_width=5,
            ),
            expand=False,
        )
        self._alert_dialog.visible = True
        self._alert_dialog.content = self._loading_dialog
        self._alert_dialog.update()

    def hideLoading(self):
        """
        Hide the loading dialog.
        """
        self._alert_dialog.visible = False
        self._alert_dialog.update()
        self._alert_dialog.content = None
        print("hideLoading end")

    def showErrorMessage(self, message: str):
        print("showErrorMessage")
        self._error_dialog = ft.Container(
            width=400,
            height=400,
            alignment=ft.Alignment(0, 0),
            bgcolor=ft.colors.BACKGROUND,
            border_radius=10,
            content=ft.Column(
                expand=False,
                controls=[
                    ft.Icon(
                        name=ft.icons.ERROR,
                        size=100,
                        color="#D43131C5",
                    ),
                    ft.Text(
                        message,
                        size=32,
                        text_align=ft.TextAlign.CENTER,
                        weight=ft.FontWeight.W_400,
                    ),
                    ft.ElevatedButton(
                        text="CLOSE",
                        on_click=lambda e: self.hideErrorMessage(),
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_EVENLY,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )
        self._alert_dialog.visible = True
        self._alert_dialog.content = self._error_dialog
        self._alert_dialog.update()

    def hideErrorMessage(self):
        self._alert_dialog.visible = False
        self._alert_dialog.update()
        self._alert_dialog.content = None

    def __new__(
        cls,
        page: ft.Page,
        route: str,
        view_pop: callable(any),
    ) -> ft.View:
        print("SheetPage new")
        self = super().__new__(cls)
        self.route = route
        self._page = page
        self.view_pop = view_pop

        self._alert_dialog = ft.Container(
            visible=False,
            expand=True,
            alignment=ft.Alignment(0, 0),
            bgcolor=ft.colors.BLACK38,
        )

        self.firebaseConnect = FirebaseConnect()

        ## contenido

        ## titulo
        page_title = ft.Container(
            content=ft.Text(
                "Registro en MONFEDIS",
                size=32,
                text_align="center",
                font_family="century gothic",
                color="#1D5B79",
                weight=ft.FontWeight.W_400,
            ),
            alignment=ft.alignment.center,
            width=600,
            border_radius=100,
            padding=ft.padding.symmetric(horizontal=10),
            bgcolor="#0F5663C6",
        )

        def button_clicked(e):
            # t.value = f"Datos Registro Entrenador: '{nombre_coach.value}', '{apellido_coach.value}', '{email_coach.value}', '{password_coach.value}', '{conf_password_coach.value}'. "
            # t.update()
            self.showLoading()
            name = nombre_coach.value
            lastname = apellido_coach.value
            email = email_coach.value
            password = password_coach.value
            conf_password = conf_password_coach.value
            if name is None or name == "":
                self.showErrorMessage(f"El nombre es requerido")
                return
            if lastname is None or lastname == "":
                self.showErrorMessage(f"El apellido es requerido")
                return
            if email is None or email == "":
                self.showErrorMessage(f"El email es requerido")
                return
            if password is None or password == "":
                self.showErrorMessage(f"La contraseña es requerida")
                return
            if conf_password is None or conf_password == "":
                self.showErrorMessage(f"La confirmacion de contraseña es requerida")
                return
            if password != conf_password:
                self.showErrorMessage(f"Las contraseñas no coinciden")
                return

            try:
                response = self.firebaseConnect.signUp(email, password)
                if isinstance(response, FirebaseAuth):
                    print(f"Registro de Entrenador: {response}")
                    loadData = self.firebaseConnect.putData(
                        path=f"us_{response.localId}/",
                        data={
                            "userInformation": {
                                "name": name,
                                "lastname": lastname,
                                "email": email,
                            }
                        },
                        token=response.idToken,
                    )
                    
                    if loadData:
                        self.showErrorMessage(f"Registro Exitoso")
                        self.go("/home", firebaseAuthString=response.model_dump_json())
                        #self.view_pop(None)
                        self.hideLoading()
                    else:
                        self.showErrorMessage(f"Registro Fallido")
                else:
                    if response == "EMAIL_EXISTS":
                        self.showErrorMessage(f"El correo ya existe")
                    else:
                        self.showErrorMessage(f"Registro Fallido")

            except Exception as e:
                print(e)
                self.showErrorMessage(f"Registro Fallido")

        t = ft.Text()
        nombre_coach = ft.TextField(label="Nombre")
        apellido_coach = ft.TextField(label="Apellido")
        email_coach = ft.TextField(label="Email")
        password_coach = ft.TextField(
            label="Contraseña",
            password=True,
            can_reveal_password=True,
        )
        conf_password_coach = ft.TextField(
            label="Confirmar Contraseña",
            password=True,
            can_reveal_password=True,
        )

        Botones = ft.Container(
            content=ft.Row(
                [
                    ft.ElevatedButton(text="Registrar", on_click=button_clicked),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
            )
        )

        self._view = ft.View(
            route=self.route,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            vertical_alignment=ft.MainAxisAlignment.CENTER,
            fullscreen_dialog=True,
            controls=[
                ft.Stack(
                    width=self._page.window_width,
                    height=self._page.window_height,
                    controls=[
                        ft.IconButton(
                            icon=ft.icons.ARROW_BACK,
                            icon_size=30,
                            tooltip="Back",
                            on_click=lambda e: self.view_pop(None),
                        ),
                        ft.Column(
                            alignment=ft.MainAxisAlignment.START,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=[
                                page_title,
                                ft.Container(
                                    expand=True,
                                    alignment=ft.Alignment(0, 0),
                                    content=ft.Column(
                                        scroll=ft.ScrollMode.AUTO,
                                        controls=[
                                            ft.Row(
                                                [nombre_coach],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [apellido_coach],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [email_coach],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [password_coach],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [conf_password_coach],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [t],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                            ft.Row(
                                                [Botones],
                                                alignment=ft.MainAxisAlignment.CENTER,
                                            ),
                                        ],
                                    ),
                                ),
                            ],
                        ),
                        self._alert_dialog,
                    ],
                ),
            ],
        )
        return self._view
