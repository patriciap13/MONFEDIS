import json
import random
import re
from faker import Faker
import flet as ft
from pydantic import InstanceOf
import requests

from models.FirebaseAuth import FirebaseAuth
from models.FirebaseConnect import FirebaseConnect


class SportmanPage:
    _page: ft.Page
    route: str
    view_pop: callable(any)

    firebaseConnect: FirebaseConnect

    firebaseAuth: FirebaseAuth

    _alert_dialog: ft.Container

    _loading_dialog: ft.AlertDialog
    _error_dialog: ft.Control

    _view: ft.View

    def showLoading(self):
        """
        Show a loading dialog.
        """

        self._loading_dialog = ft.Container(
            width=100,
            height=100,
            alignment=ft.Alignment(0, 0),
            content=ft.ProgressRing(
                width=100,
                height=100,
                expand=True,
                stroke_width=5,
            ),
            expand=False,
        )
        self._alert_dialog.visible = True
        self._alert_dialog.content = self._loading_dialog
        self._alert_dialog.update()

    def hideLoading(self):
        """
        Hide the loading dialog.
        """
        self._alert_dialog.visible = False
        self._alert_dialog.update()
        self._alert_dialog.content = None
        print("hideLoading end")

    def showErrorMessage(self, message: str):
        print("showErrorMessage")
        self._error_dialog = ft.Container(
            width=400,
            height=400,
            alignment=ft.Alignment(0, 0),
            bgcolor=ft.colors.BACKGROUND,
            border_radius=10,
            content=ft.Column(
                expand=False,
                controls=[
                    ft.Icon(
                        name=ft.icons.ERROR,
                        size=100,
                        color="#D43131C5",
                    ),
                    ft.Text(
                        message,
                        size=32,
                        text_align=ft.TextAlign.CENTER,
                        weight=ft.FontWeight.W_400,
                    ),
                    ft.ElevatedButton(
                        text="CLOSE",
                        on_click=lambda e: self.hideErrorMessage(),
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_EVENLY,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )
        self._alert_dialog.visible = True
        self._alert_dialog.content = self._error_dialog
        self._alert_dialog.update()

    def hideErrorMessage(self):
        self._alert_dialog.visible = False
        self._alert_dialog.update()
        self._alert_dialog.content = None

    def __new__(
        cls,
        page: ft.Page,
        route: str,
        firebaseAuthString: str,
        sportmanString: str,
        view_pop: callable(any),
    ) -> ft.View:
        print("SheetPage new")
        self = super().__new__(cls)
        self.route = route
        self._page = page
        self.view_pop = view_pop

        self.firebaseAuth = FirebaseAuth.model_validate_json(firebaseAuthString)
        sportman = json.loads(sportmanString)

        self._alert_dialog = ft.Container(
            visible=False,
            expand=True,
            alignment=ft.Alignment(0, 0),
            bgcolor=ft.colors.BLACK38,
        )

        self.firebaseConnect = FirebaseConnect()

        ## contenido

        ## titulo
        page_title = ft.Container(
            content=ft.Text(
                value="Datos del Deportista",
                size=32,
                text_align="center",
                font_family="century gothic",
                color="#1D5B79",
                weight=ft.FontWeight.W_400,
            ),
            alignment=ft.alignment.center,
            width=600,
            border_radius=100,
            padding=ft.padding.symmetric(horizontal=10),
            bgcolor="#0F5663C6",
        )

        userInformation = []

        userInformation.append(
            ft.Container(
                content=ft.Text(
                    value=f"Nombre: {sportman['userInformation']['name']}",
                    size=22,
                    text_align="center",
                    font_family="century gothic",
                    color="#1D5B79",
                    weight=ft.FontWeight.W_400,
                ),
                width=300,
                alignment=ft.alignment.center,
                border_radius=100,
                padding=ft.padding.symmetric(horizontal=10),
                bgcolor="#0F5663C6",
            ),
        )
        userInformation.append(
            ft.Container(
                content=ft.Text(
                    value=f"Apellido: {sportman['userInformation']['lastname']}",
                    size=22,
                    text_align="center",
                    font_family="century gothic",
                    color="#1D5B79",
                    weight=ft.FontWeight.W_400,
                ),
                width=300,
                alignment=ft.alignment.center,
                border_radius=100,
                padding=ft.padding.symmetric(horizontal=10),
                bgcolor="#0F5663C6",
            ),
        )
        userInformation.append(
            ft.Container(
                content=ft.Text(
                    value=f"Documento: {sportman['userInformation']['document']}",
                    size=22,
                    text_align="center",
                    font_family="century gothic",
                    color="#1D5B79",
                    weight=ft.FontWeight.W_400,
                ),
                width=300,
                alignment=ft.alignment.center,
                border_radius=100,
                padding=ft.padding.symmetric(horizontal=10),
                bgcolor="#0F5663C6",
            ),
        )
        userInformation.append(
            ft.Container(
                content=ft.Text(
                    value=f"Genero: {sportman['userInformation']['gender']}",
                    size=22,
                    text_align="center",
                    font_family="century gothic",
                    color="#1D5B79",
                    weight=ft.FontWeight.W_400,
                ),
                width=300,
                alignment=ft.alignment.center,
                border_radius=100,
                padding=ft.padding.symmetric(horizontal=10),
                bgcolor="#0F5663C6",
            ),
        )
        userInformation.append(
            ft.Container(
                content=ft.Text(
                    value=f"Edad: {sportman['userInformation']['age']}",
                    size=22,
                    text_align="center",
                    font_family="century gothic",
                    color="#1D5B79",
                    weight=ft.FontWeight.W_400,
                ),
                width=300,
                alignment=ft.alignment.center,
                border_radius=100,
                padding=ft.padding.symmetric(horizontal=10),
                bgcolor="#0F5663C6",
            ),
        )
        userInformation.append(
            ft.Container(
                content=ft.Text(
                    value=f"Peso: {sportman['userInformation']['weight']}",
                    size=22,
                    text_align="center",
                    font_family="century gothic",
                    color="#1D5B79",
                    weight=ft.FontWeight.W_400,
                ),
                width=300,
                alignment=ft.alignment.center,
                border_radius=100,
                padding=ft.padding.symmetric(horizontal=10),
                bgcolor="#0F5663C6",
            ),
        )
        userInformation.append(
            ft.Container(
                content=ft.Text(
                    value=f"Altura: {sportman['userInformation']['height']}",
                    size=22,
                    text_align="center",
                    font_family="century gothic",
                    color="#1D5B79",
                    weight=ft.FontWeight.W_400,
                ),
                width=300,
                alignment=ft.alignment.center,
                border_radius=100,
                padding=ft.padding.symmetric(horizontal=10),
                bgcolor="#0F5663C6",
            ),
        )

        deportista_data = []

        def open_sporty(e):
            print("open_sporty")
            print(e.control.data)
            data = json.dumps(e.control.data)
            self._page.go(
               "/result",
               firebaseAuth=self.firebaseAuth.model_dump_json(),
               sportmanResult=data,
            )

        for key in sportman["data"]:
            deportista_data.append(
                ft.ListTile(
                    width=400,
                    title=ft.Text(key),
                    data=sportman["data"][key],
                    on_click=open_sporty,
                )
            )
            
        def star_capture(e):
            print("star_capture")
            print(e.control.data)
            data = json.dumps(e.control.data)
            self._page.go(
                "/capture",
                firebaseAuth=self.firebaseAuth.model_dump_json(),
                sportman=data,
            )

        self._view = ft.View(
            route=self.route,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            vertical_alignment=ft.MainAxisAlignment.CENTER,
            fullscreen_dialog=True,
            controls=[
                ft.Stack(
                    width=self._page.window_width,
                    height=self._page.window_height,
                    controls=[
                        ft.IconButton(
                            icon=ft.icons.ARROW_BACK,
                            icon_size=30,
                            tooltip="Back",
                            on_click=lambda e: self.view_pop(None),
                        ),
                        ft.Column(
                            alignment=ft.MainAxisAlignment.START,
                            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                            controls=[
                                page_title,
                                ft.Divider(
                                    color=ft.colors.TRANSPARENT,
                                ),
                                ft.Row(
                                    userInformation,
                                    alignment=ft.MainAxisAlignment.CENTER,
                                    vertical_alignment=ft.CrossAxisAlignment.START,
                                    wrap=True,
                                ),
                                ft.Row(
                                    [
                                        ft.Text(
                                            value="Datos del Deportista:",
                                            size=32,
                                            text_align="center",
                                            font_family="century gothic",
                                            color="#1D5B79",
                                            weight=ft.FontWeight.W_400,
                                        ),
                                    ],
                                    alignment=ft.MainAxisAlignment.CENTER,
                                    vertical_alignment=ft.CrossAxisAlignment.START,
                                    wrap=True,
                                ),
                                ft.Container(
                                    expand=True,
                                    alignment=ft.Alignment(0, 0),
                                    content=ft.Column(
                                        scroll=ft.ScrollMode.AUTO,
                                        alignment=ft.MainAxisAlignment.START,
                                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                        controls=deportista_data,
                                    ),
                                ),
                            ],
                        ),
                        ft.FloatingActionButton(
                            icon=ft.icons.START,  # the icon name, that must be material Icons
                            bgcolor="#D5EFF6",
                            on_click=star_capture,  # the on_click event
                            bottom=60,
                            right=15,
                            tooltip="Iniciar Toma de Datos"
                        ),
                        self._alert_dialog,
                    ],
                ),
            ],
        )
        return self._view
