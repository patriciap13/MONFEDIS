import random
import flet as ft
from urllib.parse import parse_qs, urlparse, parse_qsl
from getpass import getpass
import requests
import json
from models.FirebaseAuth import FirebaseAuth
from models.FirebaseConnect import FirebaseConnect
from pages.HomePage import HomePage



from pages.RegisterPage import RegisterPage
from pages.ResultPage import ResultPage
from pages.SportmanPage import SportmanPage


def main(page: ft.Page):
    # define the page title
    page.title = "MONFEDIS APP"
    page.window_maximized = True
    page.padding = 0

    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    page.theme = ft.Theme(
        font_family="century gothic",
    )



    def showLoading():
        """
        Show a loading dialog.
        """
        nonlocal _alert_dialog
        _loading_dialog = ft.Container(
            width=100,
            height=100,
            alignment=ft.Alignment(0, 0),
            content=ft.ProgressRing(
                width=100,
                height=100,
                expand=True,
                stroke_width=5,
            ),
            expand=False,
        )
        _alert_dialog.visible = True
        _alert_dialog.content = _loading_dialog
        _alert_dialog.update()

    def hideLoading():
        """
        Hide the loading dialog.
        """
        nonlocal _alert_dialog
        _alert_dialog.visible = False
        _alert_dialog.update()
        _alert_dialog.content = None

    def showErrorMessage(message: str):
        nonlocal _alert_dialog
        print("showErrorMessage")
        _error_dialog = ft.Container(
            width=400,
            height=400,
            alignment=ft.Alignment(0, 0),
            bgcolor=ft.colors.BACKGROUND,
            border_radius=10,
            content=ft.Column(
                expand=False,
                controls=[
                    ft.Icon(
                        name=ft.icons.ERROR,
                        size=100,
                        color="#D43131C5",
                    ),
                    ft.Text(
                        message,
                        size=32,
                        text_align=ft.TextAlign.CENTER,
                        weight=ft.FontWeight.W_400,
                    ),
                    ft.ElevatedButton(
                        text="CLOSE",
                        on_click=lambda e: hideErrorMessage(),
                    ),
                ],
                alignment=ft.MainAxisAlignment.SPACE_EVENLY,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
        )
        _alert_dialog.visible = True
        _alert_dialog.content = _error_dialog
        _alert_dialog.update()

    def hideErrorMessage():
        nonlocal _alert_dialog
        _alert_dialog.visible = False
        _alert_dialog.update()
        _alert_dialog.content = None

    def route_change(route: ft.ControlEvent):
        showLoading()
        try:
            parsed_url = urlparse(route.route)
            if page.views[-1].route == parsed_url.path:
                return
            #if len(page.views) > 1:
            #    page.views.pop()
            params = parse_qs(parsed_url.query)

            if parsed_url.path == "/register":
                page.views.append(
                    RegisterPage(
                        route="/register",
                        page=page,
                        view_pop=view_pop,
                        # sheet_title=title,
                    )
                )
            if parsed_url.path == "/home":
                if len(page.views) > 1:
                    page.views.pop()
                firebaseAuthString = params["firebaseAuth"][0] if "firebaseAuth" in params else None
                page.views.append(
                    HomePage(
                        route="/home",
                        page=page,
                        view_pop=view_pop,
                        firebaseAuthString=firebaseAuthString,
                    )
                )
            if parsed_url.path == "/sportman":
                firebaseAuthString = params["firebaseAuth"][0] if "firebaseAuth" in params else None
                sportmanString = params["sportman"][0] if "sportman" in params else None
                page.views.append(
                    SportmanPage(
                        route="/sportman",
                        page=page,
                        view_pop=view_pop,
                        firebaseAuthString=firebaseAuthString,
                        sportmanString=sportmanString,
                    )
                )    
                
            if parsed_url.path == "/result":
                firebaseAuthString = params["firebaseAuth"][0] if "firebaseAuth" in params else None
                sportmanResultString = params["sportmanResult"][0] if "sportmanResult" in params else None
                page.views.append(
                    ResultPage(
                        route="/result",
                        page=page,
                        view_pop=view_pop,
                        firebaseAuthString=firebaseAuthString,
                        sportmanResultString=sportmanResultString,
                    )
                )  
            

            page.update()
            hideLoading()
        except Exception as e:
            print(e)
            showErrorMessage(f"Error loading page")

    def view_pop(view):
        page.views.pop()
        # page.views[-1].update()
        # page.update()

        top_view = page.views[-1]
        page.route = top_view.route
        # page.update()
        page.go(top_view.route)

    page.on_route_change = route_change
    page.on_view_pop = view_pop

    ## titulo
    page_title = ft.Container(
        content=ft.Text(
            "MONFEDIS",
            size=32,
            text_align="center",
            font_family="century gothic",
            color="#1D5B79",
            weight=ft.FontWeight.W_400,
        ),
        alignment=ft.alignment.center,
        width=600,
        border_radius=100,
        padding=ft.padding.symmetric(horizontal=10),
        bgcolor="#0F5663C6",
    )

    _alert_dialog = ft.Container(
        visible=False,
        expand=True,
        alignment=ft.Alignment(0, 0),
        bgcolor=ft.colors.BLACK38,
    )

    def login_button_clicked(e):
        showLoading()
        firebaseConnect = FirebaseConnect()
        #t.value = f"Inicio de Sesion: '{email_coach.value}', '{password_coach.value}'. "
        #t.update()
        try:
            response = firebaseConnect.signInWithPassword(email_coach.value, password_coach.value)
            if response:
                print(f"Inicio de Sesion: {response}")
                page.go(f"/home", firebaseAuth=response.model_dump_json())
                hideLoading()
            else:
                showErrorMessage(f"Inicio de Sesion Fallido")
            
        except Exception as e:
            print(e)
            showErrorMessage(f"Inicio de Sesion Fallido")
            
    
    def register_button_clicked(e):
        showLoading()
        page.go("/register")
        hideLoading()

    t = ft.Text()
    email_coach = ft.TextField(label="Email")
    password_coach = ft.TextField(
        label="Contraseña",
        password=True,
        can_reveal_password=True,
    )

    Botones_sesion = ft.Container(
        content=ft.Row(
            [
                ft.ElevatedButton(text="Acceder", on_click=login_button_clicked),
                ft.ElevatedButton(text="Registrarse", on_click=register_button_clicked),
            ],
            alignment=ft.MainAxisAlignment.CENTER,
        )
    )

    olvido_pass = ft.Container(
        content=ft.Row(
            [ft.TextButton(text="¿Has Olvidado la Contraseña?")],
            alignment=ft.MainAxisAlignment.CENTER,
        )
    )

    page.add(
        ft.Stack(
            width=page.window_width,
            height=page.window_height,
            controls=[
                #ft.IconButton(
                #    icon=ft.icons.ARROW_BACK,
                #    icon_size=30,
                #    tooltip="Back",
                #    on_click=lambda e: view_pop(None),
                #),
                ft.Column(
                    alignment=ft.MainAxisAlignment.CENTER,
                    horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        page_title,
                        ft.Container(
                            expand=True,
                            alignment=ft.Alignment(0, 0),
                            content=ft.Column(
                                scroll=ft.ScrollMode.AUTO,
                                controls=[
                                    ft.Row(
                                        [email_coach],
                                        alignment=ft.MainAxisAlignment.CENTER,
                                    ),
                                    ft.Row(
                                        [password_coach],
                                        alignment=ft.MainAxisAlignment.CENTER,
                                    ),
                                    ft.Row(
                                        [t],
                                        alignment=ft.MainAxisAlignment.CENTER,
                                    ),
                                    ft.Row(
                                        [Botones_sesion],
                                        alignment=ft.MainAxisAlignment.CENTER,
                                    ),
                                    #ft.Row(
                                    #    [olvido_pass],
                                    #    alignment=ft.MainAxisAlignment.CENTER,
                                    #),
                                ],
                            ),
                        ),
                    ],
                ),
                _alert_dialog,
            ],
        ),
    )

    page.update()  # update the page to show the changes


ft.app(target=main, name="GMT APP", view=ft.AppView.FLET_APP)
