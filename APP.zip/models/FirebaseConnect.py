

import json
import requests

from models.FirebaseAuth import FirebaseAuth


class FirebaseConnect:
    def __init__(self, apiKey:str ='AIzaSyDKqRz-5vTzEOlaYGd66YEQA72YeISa6Vc', rtdbHost: str = 'monitorcardiacogps-default-rtdb.firebaseio.com'):
        self.apiKey = apiKey
        self.rtdbHost = rtdbHost
        
    def signInWithPassword(self, email, password):
        url = f'https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key={self.apiKey}'
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        data = {
            'email': email,
            'password': password,
            'returnSecureToken': True
        }
        
        response = requests.post(url, headers=headers, data=json.dumps(data))
        
        if response.status_code == 200:
            # La solicitud fue exitosa
            response_data = response.json()
            print(f"Registro de Entrenador: {response_data}")
            return FirebaseAuth(**response_data)
        elif response.status_code == 400:
            # La solicitud falló, puedes manejar el error como desees
            print(f"Error {response.status_code}: {response.text}")
            json_data = json.loads(response.text)
            if 'error' in json_data:
                if 'message' in json_data['error']:
                    return json_data['error']['message']
        else:
            return None
        
        
    def signUp(self, email, password):
        url = f'https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={self.apiKey}'
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        data = {
            'email': email,
            'password': password,
            'returnSecureToken': True
        }
        
        response = requests.post(url, headers=headers, data=json.dumps(data))
        
        if response.status_code == 200:
            # La solicitud fue exitosa
            response_data = response.json()
            print(f"Registro de Entrenador: {response_data}")
            return FirebaseAuth(**response_data)
        elif response.status_code == 400:
            # La solicitud falló, puedes manejar el error como desees
            print(f"Error {response.status_code}: {response.text}")
            json_data = json.loads(response.text)
            if 'error' in json_data:
                if 'message' in json_data['error']:
                    return json_data['error']['message']
        else:
            return None
    
        
    def putData(self, path, data:dict, token):
        url = f'https://{self.rtdbHost}/{path}.json?auth={token}'
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        response = requests.put(url, headers=headers, data=json.dumps(data))
        
        if response.status_code == 200:
            # La solicitud fue exitosa
            response_data = response.json()
            print(f"Registro de Entrenador: {response_data}")
            return response_data
        elif response.status_code == 400:
            # La solicitud falló, puedes manejar el error como desees
            print(f"Error {response.status_code}: {response.text}")
            json_data = json.loads(response.text)
            if 'error' in json_data:
                if 'message' in json_data['error']:
                    return json_data['error']['message']
        else:
            return None
        
    def getData(self, path, token):
        url = f'https://{self.rtdbHost}/{path}.json?auth={token}'
        
        headers = {
            'Content-Type': 'application/json'
        }
        
        response = requests.get(url, headers=headers)
        
        if response.status_code == 200:
            # La solicitud fue exitosa
            response_data = response.json()
            print(f"Registro de Entrenador: {response_data}")
            return response_data
        elif response.status_code == 400:
            # La solicitud falló, puedes manejar el error como desees
            print(f"Error {response.status_code}: {response.text}")
            json_data = json.loads(response.text)
            if 'error' in json_data:
                if 'message' in json_data['error']:
                    return json_data['error']['message']
        else:
            return None