"""
This code snippet reads a file, converts the data in the file to a list of numbers, applies a bandpass filter to the signal, detects peaks in the filtered signal, and plots the original signal, filtered signal, and detected peaks.

Inputs:
- filename: the path to the file to be read and processed.

Outputs:
- Plots of the original signal, filtered signal, and detected peaks.
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

# Definimos la frecuencia de muestreo es la inciial del dataset 250Hz
fs = 250
# import file picker
from tkinter import Tk
from tkinter.filedialog import askopenfilename

Tk().withdraw()  # we don't want a full GUI, so keep the root window from appearing
filename = (
    askopenfilename()
)  # show an "Open" dialog box and return the path to the selected file
print(filename)
# read the string from a file
"""./3_data_9333.txt"""
with open(filename, "r") as file:
    data = file.read().replace("\n", "")

# convert the string to a list of numbers

data = data.split(",")
x = [float(i) for i in data]

x_old = x

# downsample the signal se estabelce la frecuencia de la señal en 125Hz por eso se hace un downsample de 2
x = signal.decimate(x, 2, ftype="fir", axis=-1, zero_phase=True)

#### --------------------------------------------------------------------
##

# set the x to int
x = np.array(x, dtype=int)

# get the new fs se oobtiene la nueva fecuencia de muestreo que es 125Hz
fs = fs / 2

# Definimos el tiempo de muestreo
t = np.arange(0, len(x) / fs, 1 / fs)  # se crea un vector de tiempo

# create an analog bandpass butterworth filter
# with a Frequency band of 17 Hz
f = 17
f1 = (f - (5 / 2)) * 2 * np.pi
f2 = (f + (5 / 2)) * 2 * np.pi
# wn = f*2*np.pi
N = 1
b, a = signal.iirfilter(N, [f1, f2], btype="bandpass", analog=True, ftype="butter")

# estos parametros son el resultado de la funcion iirfilter pero de una señal analoga
# ws, hs = signal.freqs(b, a)

print(f"{b=}\n{a=}")

# aca se convierte en digital la señal analogica con la frecuencia de muestreo de 125Hz
# convert the filter to a digital filter
filtz = signal.dlti(*signal.bilinear(b, a, fs))
print(f"{filtz.output=}")
# aca se imprime el numerador y denominador de la funcion de transferencia del filtro digital

# apply the filter to the signal
# y = signal.lfilter(filtz.num, filtz.den, x)

# este es el resultado del filtro
# H(z) = (0.09634836 + 0z^(-1) - 0.09634836z^(-2)) / (1 + (-1.25956033)z^(-1) + 0.80730328z^(-2))


## --------------------------------------------------------------------

# se aplica el filtro a la señal de entrada

y = np.zeros(len(x))

for i in range(0, len(x)):
    # evaluate filter iir with b and a

    value = (
        (x[i] * 0.09634836)
        + (x[i - 1] * 0 if i > 0 else 0)
        + (x[i - 2] * -0.09634836 if i > 1 else 0)
        - (y[i - 1] * -1.25956033 if i > 0 else 0)
        - (y[i - 2] * 0.80730328 if i > 1 else 0)
    )

    y[i] = value


# create 2 plots
fig, (ax1, ax2) = plt.subplots(2, 1, sharex=True)
plt.rcParams["figure.figsize"] = [14, 8]
ax1.plot(t, x, label="Señal original")
ax1.set_ylabel("Amplitud")
ax1.legend()
ax1.grid()
ax2.plot(t, y, label="Señal filtrada")
ax2.set_ylabel("Amplitud")
ax2.set_xlabel("Tiempo [s]")
ax2.legend()
ax2.grid()
plt.show()

# se le aplica un umbral a la señal filtrada para detectar los picos
# detect the umbral
umbral = 41  # 0.03
y = np.array(y)


for i in range(0, len(y)):
    if y[i] < -umbral:
        y[i] = 4095
    elif y[i] > umbral:
        y[i] = 4095
    else:
        y[i] = 0

# show the result and the signal in one plot
plt.rcParams["figure.figsize"] = [14, 8]
plt.plot(t, x, label="Señal original")
plt.plot(t, y, label="Señal filtrada")


# read each 1 and set in peaks the 1 per 288ms and the rest to 0
nums_of_ones_per_100ms = int(0.288 * fs)
print(f"{nums_of_ones_per_100ms=}")
peaks = np.zeros(len(y))
for i in range(0, len(y) - 1):
    if y[i] == 4095:
        # print(i)
        peaks[i : i + nums_of_ones_per_100ms] = 4095
        i = i + nums_of_ones_per_100ms

# show the result and the signal in one plot
plt.plot(t, peaks, label="Pulsos detectados")
plt.ylabel("Amplitud")
plt.xlabel("Tiempo [s]")
plt.legend()
plt.grid()
plt.show()

